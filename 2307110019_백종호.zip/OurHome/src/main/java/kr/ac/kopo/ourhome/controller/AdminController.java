package kr.ac.kopo.ourhome.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
public class AdminController {
	final String path = "admin/";
			
	@GetMapping("/")
	String index() {
		return path + "index";
	}

}
