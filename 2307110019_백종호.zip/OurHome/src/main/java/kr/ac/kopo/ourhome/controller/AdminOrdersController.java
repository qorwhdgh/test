package kr.ac.kopo.ourhome.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.ac.kopo.ourhome.model.Orders;
import kr.ac.kopo.ourhome.pager.Pager;
import kr.ac.kopo.ourhome.service.OrdersService;

@Controller
@RequestMapping("/admin/orders")
public class AdminOrdersController {
	final String path = "admin/orders/";
	
	@Autowired
	OrdersService service;
	
	@GetMapping("/detail/{orderid}")
	String detail(@PathVariable Long orderid, Model model) {
		Orders item = service.item(orderid);
		
		model.addAttribute("item", item);
		
		return path + "detail";
	}
	
	@GetMapping("/list")
	String list(Model model, Pager pager) {
		List<Orders> list = service.list(pager);
		
		model.addAttribute("list", list);
		
		return path + "list";
	}
	
	@GetMapping("/delete/{orderid}")
	String delete(@PathVariable Long orderid) {
		
		service.delete(orderid);
		
		return "redirect:../list";
	}
}
