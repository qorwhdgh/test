package kr.ac.kopo.ourhome.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttribute;

import kr.ac.kopo.ourhome.model.Detail;


@RestController
@RequestMapping("/cart")
public class CartController {

	@PostMapping("/update_all")
	String updateAll(@RequestBody List<Detail> list, @SessionAttribute("cart") HashMap<Long, Integer> cart) {
		for(Detail item : list)
			cart.put(item.getProductid(), item.getAmount().intValue());
		
		return "OK";
	}
	
	@PostMapping("/del_check")
	String delCheck(@RequestBody Long[] list, @SessionAttribute("cart") HashMap<Long, Integer> cart) {
		for(Long productid : list)
			cart.remove(productid);
			
		return "OK";
	}

	@GetMapping("/delete/{productid}")
	String deleteCart(@PathVariable Long productid, @SessionAttribute("cart") HashMap<Long, Integer> cart) {
		if(cart.remove(productid) != null)
			return "OK";
		
		return "FAIL";
	}
	
	@GetMapping("/update/{productid}/{amount}")
	String updateCart(@PathVariable Long productid, @PathVariable Integer amount,@SessionAttribute("cart") HashMap<Long, Integer> cart) {
		if(cart.put(productid, amount) != null)
			return "OK";
		
		return "FAIL";
	}
	
	@GetMapping(value="/add/{productid}", produces="plain/text;charset=utf-8") // long값을 찾으면 Integer 값이 나옴(2개 밑에)
	String addCart(@PathVariable Long productid, 
			@SessionAttribute(name ="cart", required = false) HashMap<Long, Integer> cart, HttpSession session
			) {

		if(cart == null) {
			cart = new HashMap<Long, Integer>();
			session.setAttribute("cart", cart);
		}
		
		Integer amount = cart.get(productid);
		
		if(amount == null)
			cart.put(productid, 1);
		else
			cart.put(productid, amount + 1);
		
		return "장바구니 담기: " + productid + ", 수량: " + cart.get(productid);
	}
}
