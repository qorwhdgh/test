package kr.ac.kopo.ourhome.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import kr.ac.kopo.ourhome.model.Community;
import kr.ac.kopo.ourhome.model.CommunityImage;
import kr.ac.kopo.ourhome.pager.Pager;
import kr.ac.kopo.ourhome.service.CommunityService;


@Controller
@RequestMapping("/community")
public class CommunityController {
	final String path = "community/";
	
	@Autowired
	String uploadPath;
	
	@Autowired
	CommunityService service;
	
	@GetMapping("/list")
	String list(Model model, Pager pager) {
		List<Community> list = service.list(pager);
		
		model.addAttribute("list", list);
		
		return path + "list";
	}
	
	@GetMapping("/add")
	String add() {
		return path + "add";
	}
	
	@PostMapping("/add")
	String add(Community item, List<MultipartFile> uploadFile) {
		
		List<CommunityImage> images = new ArrayList<CommunityImage>();
		
		for(MultipartFile file : uploadFile) {
			String filename =file.getOriginalFilename();
			String uuid = UUID.randomUUID().toString();
			
			System.out.println(filename);
		
			try {
				file.transferTo(new File(uploadPath + uuid + "-" + filename));
				
				
				images.add(new CommunityImage(filename, uuid));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		item.setImages(images);
		
		service.add(item);
		
		return "redirect:list";
	}
	
	@GetMapping("/update/{communityid}")
	String update(@PathVariable Long communityid, Model model) {
		Community item = service.item(communityid);
		
		model.addAttribute("item", item);
		
		return path + "update";
	}
	
	@PostMapping("/update/{communityid}")
	String update(@PathVariable Long communityid, Community item) {
		item.setCommunityid(communityid);
		
		service.update(item);
		
		return "redirect:../list";
	}
	
	@GetMapping("/delete/{communityid}")
	String delete(@PathVariable Long communityid) {
		service.delete(communityid);
		
		return "redirect:../list";
	}
	
	@GetMapping("/detail/{communityid}")
	String detail(@PathVariable Long communityid, Model model) {
		Community item = service.item(communityid);
		
		model.addAttribute("item", item);
		
		return path + "detail";
	}
	
}
