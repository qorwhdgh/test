package kr.ac.kopo.ourhome.controller;


import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttribute;

import kr.ac.kopo.ourhome.model.Member;
import kr.ac.kopo.ourhome.model.Product;
import kr.ac.kopo.ourhome.service.MemberService;
import kr.ac.kopo.ourhome.service.ProductService;

@Controller
public class RootController {
	
	@Autowired
	MemberService memberService;
	
	@Autowired
	ProductService productService;
	
	@GetMapping("/")
	String index() {
		return "index";
	}

	@GetMapping("/login")
	String login() {
		return "login";
	}
	
	@PostMapping("/login")
	String login(Member member, HttpSession session) {
		if(memberService.login(member)) {
			session.setAttribute("member", member);
			
			Long role = member.getRole();
			if(role == Member.ADMIN)
				return "redirect:/admin/";
			else if(role == Member.USER)
				return "redirect:/user/";
			
			return "redirect:/";
		}
		
		return "redirect:login";
	}
	
	@GetMapping("/logout")
	String logout(HttpSession session) {
		session.invalidate();
		
		return "redirect:/";
	}
	
	@GetMapping("/signup")
	String signup() {
		return "signup";
	}
	
	@PostMapping("/signup")
	String signup(Member item) {
		memberService.add(item);
		
		return "redirect:/";
	}
	
	@ResponseBody
	@GetMapping("/check_id/{id}")
	String checkId(@PathVariable String id) {
		if(memberService.item(id) == null) 
			return "OK";
		
		return "FAIL";
	}
	
	@GetMapping("/cart")
	 
	String cart(Model model, @SessionAttribute(name = "cart", required = false) HashMap<Long, Integer> cart) {
		if(cart != null) {
			List<Product> list = productService.list(cart);
			
			HashMap<Long, Product> map = new HashMap<Long, Product>();
			for(Product item : list)
				map.put(item.getProductid(), item);
			
			model.addAttribute("books", map);
			model.addAttribute("cart", cart);
		} else {
			model.addAttribute("cart", new HashMap<Long, Integer>());
		}
		
		return "cart";
	}
}
