package kr.ac.kopo.ourhome.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.multipart.MultipartFile;

import kr.ac.kopo.ourhome.model.Community;
import kr.ac.kopo.ourhome.model.CommunityImage;
import kr.ac.kopo.ourhome.model.Member;
import kr.ac.kopo.ourhome.pager.Pager;
import kr.ac.kopo.ourhome.service.CommunityService;

@Controller
@RequestMapping("/user/community")
public class UserCommunityController {
	final String path = "user/community/";
	
	@Autowired
	CommunityService service;
	
	private String uploadPath = "d:/community/";
	
	@GetMapping("/list")
	String list(Model model, Pager pager) {
		List<Community> list = service.list(pager);
		
		model.addAttribute("list", list);
		
		return path + "list";
	}

	@GetMapping("/add")
	String add() {
		return path + "add";
	}
	
	@PostMapping("/add")
	String add(Community item, List<MultipartFile> uploadFile, @SessionAttribute Member member) {
		item.setId(member.getId());
		
		List<CommunityImage> images = new ArrayList<CommunityImage>();
		
		for(MultipartFile file : uploadFile) {
			if(file.isEmpty())
				continue;
			
			String filename = file.getOriginalFilename();
			String uuid = UUID.randomUUID().toString();
			
			try {
				file.transferTo(new File(uploadPath  + uuid + "_" + filename));
				
				CommunityImage img = new CommunityImage(filename, uuid);
				img.setFilename(filename);
				img.setUuid(uuid);
				
				images.add(img);				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		item.setImages(images);
		
		service.add(item);
		
		return "redirect:list";
	}
	
	@GetMapping("/update/{communityid}")
	String update(@PathVariable Long communityid, Model model) {
		Community item = service.item(communityid);
		
		model.addAttribute("item", item);
		
		return path + "update";
	}
	
	@PostMapping("/update/{communityid}")
	String update(@PathVariable Long communityid, Community item, List<MultipartFile> uploadFile, @SessionAttribute Member member) {
		item.setCommunityid(communityid);
		
		List<CommunityImage> images = new ArrayList<CommunityImage>();
		
		for(MultipartFile file : uploadFile) {
			if(file != null && !file.isEmpty()) {
				String filename = file.getOriginalFilename();
				String uuid = UUID.randomUUID().toString();
				
				try {
					file.transferTo(new File(uploadPath + uuid + " " + filename));
					
					CommunityImage image = new CommunityImage(filename, uuid);
					image.setFilename(filename);
					image.setUuid(uuid);
					image.setCommunityid(communityid);
					
					images.add(image);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		item.setImages(images);
		
		service.update(item);
		
		return "redirect:../list";
	}
	
	@GetMapping("/delete/{communityid}")
	String delete(@PathVariable Long communityid) {
		service.delete(communityid);
		
		return "redirect:../list";
	}
	
	@GetMapping("/detail/{communityid}")
	String detail(@PathVariable Long communityid, Model model) {
		Community item = service.item(communityid);
		
		model.addAttribute("item", item);
		
		return path + "detail";
	}
	
	@ResponseBody
	@GetMapping("delete_image/{fileid}")
	String deleteImage(@PathVariable Long fileid) {
		CommunityImage image = service.itemImage(fileid);
		
		if(service.deleteImage (fileid)) {
			File file = new File(uploadPath + image.getUuid() + "_" + image.getFilename());
			file.delete();
			
			return "OK";
		}
		return "FAIL";
	}

}
