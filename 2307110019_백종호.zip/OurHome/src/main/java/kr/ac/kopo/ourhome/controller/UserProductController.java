package kr.ac.kopo.ourhome.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import kr.ac.kopo.ourhome.model.Product;
import kr.ac.kopo.ourhome.pager.Pager;
import kr.ac.kopo.ourhome.service.ProductService;

@Controller
@RequestMapping("/user/product")
public class UserProductController {
	final String path = "user/product/";
	
	@Autowired
	ProductService service;
	
	@GetMapping("/list")
	String list(Model model, Pager pager) {
		List<Product> list = service.list(pager);
		
		model.addAttribute("list", list);
		
		return path + "list";
	}
	
	@GetMapping("/detail/{productid}")
	String detail(@PathVariable Long productid, Model model) {
		Product item = service.item(productid);
		
		model.addAttribute("item", item);
		
		return path + "detail";
	}
	
	@GetMapping("/cart")
	String cart(Model model, @SessionAttribute(name = "cart", required = false) HashMap<Long, Integer> cart) {
		
		if(cart != null) {
			List<Product> list = service.list(cart);
			
			HashMap<Long, Product> map = new HashMap<Long, Product>();
			for(Product item : list) {
				map.put(item.getProductid(), item);
			}
			
			model.addAttribute("products", map);
			model.addAttribute("cart", cart);
		} else {
			model.addAttribute("cart", new HashMap<Long, Integer>());
		}
		
		return path + "cart";
	}

	 
	 
	
}
