package kr.ac.kopo.ourhome.dao;

import java.util.HashMap;
import java.util.List;

import kr.ac.kopo.ourhome.model.Community;
import kr.ac.kopo.ourhome.model.CommunityImage;
import kr.ac.kopo.ourhome.pager.Pager;

public interface CommunityDao {

	void add(Community item);

	void addImage(CommunityImage image);

	Community item(Long communityid);

	void update(Community item);

	List<Community> list(HashMap<Long, Integer> cart);

	void delete(Long communityid);

	CommunityImage itemImage(Long fileid);

	int deleteImage(Long fileid);

	int total(Pager pager);

	List<Community> list(Pager pager);

}
