package kr.ac.kopo.ourhome.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.ourhome.model.Community;
import kr.ac.kopo.ourhome.model.CommunityImage;
import kr.ac.kopo.ourhome.pager.Pager;

@Repository
public class CommunityDaoImpl implements CommunityDao {
	
	@Autowired
	SqlSession sql;

	@Override
	public void add(Community item) {
		sql.insert("community.add", item);

	}

	@Override
	public void addImage(CommunityImage image) {
		sql.insert("community.add_image", image);

	}

	@Override
	public Community item(Long communityid) {
		return sql.selectOne("community.item", communityid);
	}

	@Override
	public void update(Community item) {
		sql.update("community.update", item);
		
	}

	@Override
	public List<Community> list(HashMap<Long, Integer> cart) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		
		map.put("cart", cart);
		
		return sql.selectList("community.list_cart", map);
	}

	@Override
	public void delete(Long communityid) {
		sql.delete("community.delete", communityid);
		
	}

	@Override
	public CommunityImage itemImage(Long fileid) {
		return sql.selectOne("community.item_image", fileid);
	}

	@Override
	public int deleteImage(Long fileid) {
		return sql.delete("community.delete_image", fileid);
	}

	@Override
	public int total(Pager pager) {
		return sql.selectOne("community.total", pager);
	}

	@Override
	public List<Community> list(Pager pager) {
		return sql.selectList("community.list", pager);
	}

}
