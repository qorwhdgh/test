package kr.ac.kopo.ourhome.dao;

import java.util.List;

import kr.ac.kopo.ourhome.model.Member;
import kr.ac.kopo.ourhome.pager.Pager;

public interface MemberDao {

	Member login(Member member);

	List<Member> list();

	void add(Member item);

	Member item(String id);

	void update(Member item);

	void delete(String id);

	int total(Pager pager);

	List<Member> list(Pager pager);

}
