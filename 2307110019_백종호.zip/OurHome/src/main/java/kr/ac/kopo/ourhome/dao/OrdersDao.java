package kr.ac.kopo.ourhome.dao;

import java.util.List;

import kr.ac.kopo.ourhome.model.Detail;
import kr.ac.kopo.ourhome.model.Orders;
import kr.ac.kopo.ourhome.pager.Pager;

public interface OrdersDao {

	Orders item(Long orderid);

	void add(Orders item);

	void addDetail(Detail detail);

	void deleteDetail(Long orderid);

	void delete(Long orderid);

	int total(Pager pager);

	List<Orders> list(Pager pager);

}
