package kr.ac.kopo.ourhome.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.ourhome.model.Detail;
import kr.ac.kopo.ourhome.model.Orders;
import kr.ac.kopo.ourhome.pager.Pager;

@Repository
public class OrdersDaoImpl implements OrdersDao {
	
	@Autowired
	SqlSession sql;

	@Override
	public Orders item(Long orderid) {
		return sql.selectOne("orders.item", orderid);
	}

	@Override
	public void add(Orders item) {
		sql.insert("orders.add", item);

	}

	@Override
	public void addDetail(Detail detail) {
		sql.insert("orders.add_detail", detail);

	}

	@Override
	public void deleteDetail(Long orderid) {
		sql.delete("orders.delete_detail", orderid);
		
	}

	@Override
	public void delete(Long orderid) {
		sql.delete("orders.delete", orderid);
		
	}

	@Override
	public int total(Pager pager) {
		return sql.selectOne("orders.total", pager);
	}

	@Override
	public List<Orders> list(Pager pager) {
		return sql.selectList("orders.list", pager);
	}

}
