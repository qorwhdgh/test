package kr.ac.kopo.ourhome.dao;

import java.util.HashMap;
import java.util.List;

import kr.ac.kopo.ourhome.model.Product;
import kr.ac.kopo.ourhome.model.ProductImage;
import kr.ac.kopo.ourhome.pager.Pager;

public interface ProductDao {

	Product item(Long productid);

	void add(Product item);

	void update(Product item);

	void delete(Long productid);

	ProductImage itemImage(Long fileid);

	int deleteImage(Long fileid);

	List<Product> list(HashMap<Long, Integer> cart);

	void addImage(ProductImage image);

	int total(Pager pager);

	List<Product> list(Pager pager);

}
