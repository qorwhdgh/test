package kr.ac.kopo.ourhome.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.ourhome.model.Product;
import kr.ac.kopo.ourhome.model.ProductImage;
import kr.ac.kopo.ourhome.pager.Pager;

@Repository
public class ProductDaoImpl implements ProductDao {
	
	@Autowired
	SqlSession sql;

	@Override
	public Product item(Long productid) {
		return sql.selectOne("product.item", productid);
	}

	@Override
	public void add(Product item) {
		sql.insert("product.add", item);

	}

	@Override
	public void update(Product item) {
		sql.update("product.update", item);

	}

	@Override
	public void delete(Long productid) {
		sql.delete("product.delete", productid);

	}

	@Override
	public ProductImage itemImage(Long fileid) {
		return sql.selectOne("product.item_image", fileid);
	}

	@Override
	public int deleteImage(Long fileid) {
		return sql.delete("product.delete_image", fileid);
	}

	@Override
	public List<Product> list(HashMap<Long, Integer> cart) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		
		map.put("cart", cart);
		
		return sql.selectList("product.list_cart", map);
	}

	@Override
	public void addImage(ProductImage image) {
		sql.insert("product.add_image", image);
		
	}

	@Override
	public int total(Pager pager) {
		return sql.selectOne("product.total", pager);
	}

	@Override
	public List<Product> list(Pager pager) {
		return sql.selectList("product.list", pager);
	}

}
