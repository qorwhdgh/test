package kr.ac.kopo.ourhome.model;

import java.sql.Date;
import java.util.List;

public class Community {
	private Long communityid;
	private String id;
	private String title;
	private String detail;
	private Date ymd;
	private List<CommunityImage> images;

	public Date getYmd() {
		return ymd;
	}

	public void setYmd(Date ymd) {
		this.ymd = ymd;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getCommunityid() {
		return communityid;
	}

	public void setCommunityid(Long communityid) {
		this.communityid = communityid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public List<CommunityImage> getImages() {
		return images;
	}

	public void setImages(List<CommunityImage> images) {
		this.images = images;
	}

}
