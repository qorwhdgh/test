package kr.ac.kopo.ourhome.model;

public class CommunityImage {
	private Long fileid;
	private Long communityid;
	private String filename;
	private String uuid;
	
	public CommunityImage() {
	}
	
	public CommunityImage(String filename, String uuid) {
		this.filename = filename;
		this.uuid = uuid;
	}
	
	public Long getFileid() {
		return fileid;
	}

	public void setFileid(Long fileid) {
		this.fileid = fileid;
	}

	public Long getCommunityid() {
		return communityid;
	}

	public void setCommunityid(Long communityid) {
		this.communityid = communityid;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

}
