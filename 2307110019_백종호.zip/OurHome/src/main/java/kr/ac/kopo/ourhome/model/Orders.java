package kr.ac.kopo.ourhome.model;

import java.sql.Date;
import java.util.List;

public class Orders {
	private Long orderid;
	private String id;
	private Long saleprice;
	private Date orderdate;
	public List<Detail> details;


	public Long getSaleprice() {
		return saleprice;
	}

	public void setSaleprice(Long saleprice) {
		this.saleprice = saleprice;
	}

	public List<Detail> getDetails() {
		return details;
	}

	public void setDetails(List<Detail> details) {
		this.details = details;
	}

	public Long getOrderid() {
		return orderid;
	}

	public void setOrderid(Long orderid) {
		this.orderid = orderid;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(Date orderdate) {
		this.orderdate = orderdate;
	}

}
