package kr.ac.kopo.ourhome.model;

public class ProductImage {
	private Long fileid;
	private Long productid;
	private String filename;
	private String uuid;
	public ProductImage(String filename, String uuid) {
		this.filename = filename;
		this.uuid = uuid;
	}

	public Long getFileid() {
		return fileid;
	}

	public void setFileid(Long fileid) {
		this.fileid = fileid;
	}

	public Long getProductid() {
		return productid;
	}

	public void setProductid(Long productid) {
		this.productid = productid;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
}
