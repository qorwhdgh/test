package kr.ac.kopo.ourhome.service;

import java.util.HashMap;
import java.util.List;

import kr.ac.kopo.ourhome.model.Community;
import kr.ac.kopo.ourhome.model.CommunityImage;
import kr.ac.kopo.ourhome.pager.Pager;

public interface CommunityService {

	void add(Community item);

	Community item(Long communityid);

	void update(Community item);

	List<Community> list(HashMap<Long, Integer> cart);

	List<CommunityImage> delete(Long communityid);

	CommunityImage itemImage(Long fileid);

	boolean deleteImage(Long fileid);

	List<Community> list(Pager pager);
	
}
