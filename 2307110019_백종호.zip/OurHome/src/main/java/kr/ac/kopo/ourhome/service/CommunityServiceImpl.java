package kr.ac.kopo.ourhome.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.ourhome.dao.CommunityDao;
import kr.ac.kopo.ourhome.model.Community;
import kr.ac.kopo.ourhome.model.CommunityImage;
import kr.ac.kopo.ourhome.pager.Pager;

@Service
public class CommunityServiceImpl implements CommunityService {
	
	@Autowired
	CommunityDao dao;

	@Override
	public void add(Community item) {
		dao.add(item);
		
		if(item.getImages() != null)
			for(CommunityImage image : item.getImages()) {
				image.setCommunityid(item.getCommunityid());
				
				dao.addImage(image);
			}
	}

	@Override
	public Community item(Long communityid) {
		return dao.item(communityid);
	}

	@Override
	public void update(Community item) {
		dao.update(item);

	}

	@Override
	public List<Community> list(HashMap<Long, Integer> cart) {
		return dao.list(cart);
	}

	@Override
	public List<CommunityImage> delete(Long communityid) {
		Community item = dao.item(communityid);	// product에 image	
		
		for(CommunityImage image : item.getImages())
			dao.deleteImage(image.getFileid());
		
		dao.delete(communityid);
		return null;
		
	}

	@Override
	public CommunityImage itemImage(Long fileid) {
		return dao.itemImage(fileid);
	}

	@Override
	public boolean deleteImage(Long fileid) {
		if(dao.deleteImage(fileid) == 1)
			return true;
		
		return false;
	}

	@Override
	public List<Community> list(Pager pager) {
		int total = dao.total(pager);
		
		pager.setTotal(total);
		
		return dao.list(pager);
	}

}
