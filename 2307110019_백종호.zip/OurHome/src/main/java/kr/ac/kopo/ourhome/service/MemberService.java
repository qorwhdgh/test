package kr.ac.kopo.ourhome.service;

import java.util.List;

import kr.ac.kopo.ourhome.model.Member;
import kr.ac.kopo.ourhome.pager.Pager;

public interface MemberService {

	boolean login(Member member);

	List<Member> list();

	void add(Member item);

	Member item(String id);

	void update(Member item);

	void delete(String id);

	List<Member> list(Pager pager);

}
