package kr.ac.kopo.ourhome.service;

import java.util.HashMap;
import java.util.List;

import kr.ac.kopo.ourhome.model.Orders;
import kr.ac.kopo.ourhome.pager.Pager;

public interface OrdersService {

	Orders item(Long orderid);

	List<Orders> list(Pager pager);

	void delete(Long orderid);

	void order(String id, HashMap<Long, Integer> cart);

}
