package kr.ac.kopo.ourhome.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.ourhome.dao.ProductDao;
import kr.ac.kopo.ourhome.dao.OrdersDao;
import kr.ac.kopo.ourhome.model.Detail;
import kr.ac.kopo.ourhome.model.Orders;
import kr.ac.kopo.ourhome.model.Product;
import kr.ac.kopo.ourhome.pager.Pager;

@Service
public class OrdersServiceImpl implements OrdersService {

	@Autowired
	OrdersDao dao;
	
	@Autowired
	ProductDao productdao;
	
	@Override
	public Orders item(Long orderid) {
		
		return dao.item(orderid);
	}

	@Override
	public void order(String id, HashMap<Long, Integer> cart) {
		Orders item = new Orders();
		item.setId(id);
		
		Long saleprice = 0L;
		
		List<Product> productlist = productdao.list(cart);
		for(Product product : productlist)
			saleprice += product.getPrice() * cart.get(product.getProductid());	// price * amount
			
		item.setSaleprice(saleprice);
		
		dao.add(item);
		
		for(Long productid : cart.keySet()) {
			Detail detail = new Detail();
			detail.setProductid(productid);
			detail.setOrderid(item.getOrderid());
			detail.setAmount((long) cart.get(productid));
			
			dao.addDetail(detail);
		}
	}

	@Override
	public void delete(Long orderid) {
		dao.deleteDetail(orderid);
		
		dao.delete(orderid);
		
	}

	@Override
	public List<Orders> list(Pager pager) {
		int total = dao.total(pager);
		
		pager.setTotal(total);
		
		return dao.list(pager);
	}

}
