package kr.ac.kopo.ourhome.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.ourhome.dao.ProductDao;
import kr.ac.kopo.ourhome.model.Product;
import kr.ac.kopo.ourhome.model.ProductImage;
import kr.ac.kopo.ourhome.pager.Pager;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductDao dao;

	@Override
	public Product item(Long productid) {
		return dao.item(productid);
	}

	@Override
	public void add(Product item) {
		dao.add(item);
		
		if(item.getImages() != null)
			for(ProductImage image : item.getImages()) {
				image.setProductid(item.getProductid());
				
				dao.addImage(image);
			}

	}

	@Override
	public void update(Product item) {
		dao.update(item);

	}

	@Override
	public void delete(Long productid) {
		dao.delete(productid);

	}

	@Override
	public ProductImage itemImage(Long fileid) {
		return dao.itemImage(fileid);
	}

	@Override
	public boolean deleteImage(Long fileid) {
		if(dao.deleteImage(fileid) == 1)
			return true;
		
		return false;
	}

	@Override
	public List<Product> list(HashMap<Long, Integer> cart) {
		return dao.list(cart);
	}

	@Override
	public List<Product> list(Pager pager) {
		int total = dao.total(pager);
		
		pager.setTotal(total);
		
		return dao.list(pager);
	}

}
