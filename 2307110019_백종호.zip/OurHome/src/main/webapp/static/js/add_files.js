   // 첨부파일 여러개 업로드
   $(() => {
	const clickDelete = e => e.target.closest("li").remove();
	
	$("#add").click(e => {
	   const li = $("<li>"); //li 태그 만들기
	   li.addClass(["mt-2", "row"]);

	   const div1 = $("<div>");
	   div1.addClass(["col-1"]);
	   li.append(div1);

	   const div2 = $("<div>");
	   div2.addClass(["col"]);
	   li.append(div2);

	   const div3 = $("<div>");
	   div3.addClass(["col-1"]);
	   li.append(div3);
	   
	   const input = $("<input>"); //input 태그 만들기
	   input.attr("type", "file"); //input에 속성주기
	   input.attr("name", "uploadFile");
	   input.addClass(["form-control"]); //input에 클래스 주기
	   
	   const button = $("<button>");
	   button.text("삭제");
	   button.attr("type", "button");
	   button.addClass(["btn","btn-sm", "btn-danger"])
	   
	   button.click(clickDelete);
	   
	   div2.append(input); //div에 input 넣어주기
	   div3.append(button);
	   
	   $("#files").append(li); //form에 div 넣어주기
	});
 });