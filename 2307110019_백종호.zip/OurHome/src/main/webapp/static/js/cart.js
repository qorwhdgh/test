window.addEventListener("load", () => {
    const refresh_state = () => {
        const tbody = document.querySelector("#table_cart > tbody");

        if(tbody.childElementCount == 1) 
            tbody.querySelector(".hide").classList.remove("hide");

        const itemprice_nodes = document.querySelectorAll(".itemprice");
        const itemprice_array = Array.prototype.slice.call(itemprice_nodes) // 배열로 바꿔줌 reduce를 쓰기 위해서
        const saleprice = itemprice_array.reduce((prev, curr) => prev + Number(curr.dataset.itemprice), 0); // 0은 초기값
        document.querySelector("#saleprice").textContent = `${new Intl.NumberFormat().format(saleprice)} 원`;

    };

    document.querySelectorAll(".cart_delete").forEach(item => {
        item.addEventListener("click", e => {
            const tr = e.target.closest("tr");

            fetch(`/cart/delete/${tr.dataset.productid}`)
            .then(resp => resp.text())
            .then(result => {
                if(result == "OK") {                
                    tr.remove();
                    
                    refresh_state();
                }
            });
        });
    });

    document.querySelectorAll(".cart_update").forEach(item => {
        item.addEventListener("click", e => {
            const tr = e.target.closest("tr");
            const input = tr.querySelector("input[name='amount']");
            const price = tr.querySelector(".price").dataset.price;
            const td = tr.querySelector(".itemprice");

            fetch(`/cart/update/${tr.dataset.productid}/${input.value}`)
            .then(resp => resp.text())
            .then(result => {
                if(result == "OK") {
                    const itemprice = price * input.value;
                    td.textContent = `${new Intl.NumberFormat().format(itemprice)} 원`;
                    td.dataset.itemprice = itemprice; //dataset에 itemprice를 넣어줌

                    refresh_state();

                }
                    
            });
        });
    });

    document.querySelector("#check_all").addEventListener("change", e => {
    	const checked =e.target.checked;
    	
        document.querySelectorAll(".check_item").forEach(item => {
            item.checked = checked;
        });
    });
    
    document.querySelector("#del_check").addEventListener("click", e => {
        const list = [];
        
        document.querySelectorAll(".check_item:checked").forEach(item => {
            const tr = item.closest("tr");

            list.push( parseInt(tr.dataset.productid));
        });

        if(list.length > 0) {
            fetch("/cart/del_check", {
                method: "POST",
                body: JSON.stringify(list),
                headers: {
                    "Content-Type": "application/json" // 이게 없으면 클라이언트가 보낸 데이터를 json 객체로 인식할 수 없음
                },
            }).then(resp => resp.text())
            .then(result => {
                if(result == "OK") {
                    document.querySelectorAll(".check_item:checked").forEach(item => item.closest("tr").remove());

                    refresh_state();
                }
            });
        }
    });
    
     document.querySelector("#update_all").addEventListener("click", e => {
        list = [];

        document.querySelectorAll("input[name='amount']").forEach(item => {
            const tr = item.closest("tr");
            
            list.push({
                productid: parseInt(tr.dataset.productid),
                amount: parseInt(item.value),
            });
        });

        if(list.length > 0) {
            fetch("/cart/update_all", {
                method: "POST",
                body: JSON.stringify(list),
                headers: {
                    "Content-Type": "application/json" // 이게 없으면 클라이언트가 보낸 데이터를 json 객체로 인식할 수 없음
                },
            })
            .then(resp => resp.text())
            .then(result => {
                if(result == "OK") {
                    document.querySelectorAll("input[name='amount']").forEach(item =>  {
                        const tr = item.closest("tr");

                        const price = tr.querySelector(".price").dataset.price;
                        const itemprice = price * item.value;

                        const td = tr.querySelector(".itemprice");
                        td.textContent = `${new Intl.NumberFormat().format(itemprice)} 원`;
                        td.dataset.itemprice = itemprice; //dataset에 itemprice를 넣어줌;

                    });
                    refresh_state();
                }
            });
        }

    });
});