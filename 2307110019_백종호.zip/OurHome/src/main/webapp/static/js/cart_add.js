window.addEventListener("load", () => {
    

    document.querySelectorAll(".cart").forEach(item => {
        item.addEventListener("click", e => {
        	console.dir(e.target);
        
            const target = e.target.closest(".cart"); 
            const productid = target.dataset.productid;

       
            fetch(`/cart/add/${productid}`, {
                method: "GET",
            })
            .then(resp => resp.text())
            .then(result => alert(result));
        });
    });
});