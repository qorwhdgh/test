let checkId = false;

window.addEventListener("load", () => {
    const input = document.querySelector("input[name='id']");
    input.addEventListener("change", e => {
        checkId = false;
    });

    document.getElementById("check_id_fetch").addEventListener("click", e =>{
        // alert("FETCH");
        const id = document.querySelector("input[name='id']").value;

        fetch("check_id/" + id)
        .then(resp => resp.text())
        .then(result => {
            if(result == "OK") {
                checkId = true;
                alert("사용가능한 아이디 입니다.");
            } else
                alert("다른 사용자가 이미 등록한 아이디 입니다.");
        });
        
    });
});
