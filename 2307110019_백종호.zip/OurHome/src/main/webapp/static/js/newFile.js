window.addEventListener("load", () => {
    const input = document.querySelector("input[name='custid']");
    input.addEventListener("change", e => {
        checkId = false;
    });

    document.getElementById("check_id").addEventListener("click", () => {
        const custid = document.querySelector("input[name='custid']").value;

        const xhr = new XMLHttpRequest();

        xhr.open("GET", `check_id/${custid}`, false);

        xhr.send();

        if (xhr.responseText == "OK") {
            checkId = true;
            alert("사용가능한 아이디 입니다");
        } else {
            alert("다른 사용자가 이미 등록한 아이디 입니다");
        }
    });

    document.getElementById("check_id_async").addEventListener("click", () => {
        const custid = document.querySelector("input[name='custid']").value;

        const xhr = new XMLHttpRequest();

        xhr.open("GET", `check_id/${custid}`, true);

        xhr.onreadystatechange = () => {
            if (xhr.readyState == xhr.DONE) {
                if (xhr.status == 200) {
                    if (xhr.responseText == "OK") {
                        checkId = true;
                        alert("사용가능한 아이디 입니다");
                    } else {
                        alert("다른 사용자가 이미 등록한 아이디 입니다");
                    }
                }
            }
        };

        xhr.send();
    });
});
