window.addEventListener("load", () => {
    const buttons = document.querySelectorAll(".password_check");

    buttons.forEach(item => {
        const name = item.dataset.for;

        item.addEventListener("mousedown", e => {
            if(e.button == 0) {
                const input = document.querySelector(`input[name='${name}']`);
                input.setAttribute("type", "text");
            }        
        });
    
        const setPassword = e => {
            if(e.button == 0) {
                const input = document.querySelector(`input[name='${name}']`);
                input.setAttribute("type", "password");
            }
        };
    
        item.addEventListener("mouseup", setPassword);
        item.addEventListener("mouseout", setPassword);
    });
});