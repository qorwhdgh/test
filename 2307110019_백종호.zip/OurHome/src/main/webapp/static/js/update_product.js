window.addEventListener("load", () =>{
    document.querySelectorAll(".delete").forEach(item => {
        const li = item.closest("li");

        item.addEventListener("click", e => {
            fetch("/admin/product/delete_image/" + li.dataset.code, {
                method: "GET",
            })
            .then(resp => resp.text())
            .then(result => {
                if(result == "OK") 
                    li.remove();
            });
        })
    })
})